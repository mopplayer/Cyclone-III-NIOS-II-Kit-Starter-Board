/******************************************************************************
* Copyright (c) 2006 Altera Corporation, San Jose, California, USA.           *
* All rights reserved. All use of this software and documentation is          *
* subject to the License Agreement located at the end of this file below.     *
*******************************************************************************
*                                                                             *
* Modified to work with Interniche (week of 9/22/06) - BjR                    *
*                                                                             *
* This is an example webserver using NicheStack on the MicroC/OS-II RTOS.     *
* It is in no way a complete implementation of a webserver, it is enough to   *
* serve up our demo pages and control a few board elements and that's it.     *
*                                                                             *
* This example uses the sockets interface. A good introduction to sockets     *
* programming is the book Unix Network Programming by Richard Stevens.        *
*                                                                             *
* Please refer to file ReadMe.txt for notes on this software example.         *
******************************************************************************
* NicheStack TCP/IP stack initialization and Operating System Start in main()
* for this example. 
* 
* This example demonstrates the use of MicroC/OS-II running on NIOS II.       
* In addition it is to serve as a good starting point for designs using       
* MicroC/OS-II and Altera NicheStack TCP/IP Stack - NIOS II Edition.                                                                                           
*      
* Please refer to the Altera NicheStack Tutorial documentation for details on 
* this software example, as well as details on how to configure the NicheStack
* TCP/IP networking stack and MicroC/OS-II Real-Time Operating System.  
*/

/* MicroC/OS-II definitions */
#include "includes.h"

#include <stdio.h>
#include <errno.h>
#include <ctype.h>
#include "system.h"
#include "altera_avalon_pio_regs.h"
#include <unistd.h>

/* Web Server definitions */
#include "alt_error_handler.h"
#include "web_server.h"
#include "http.h"

/* Nichestack definitions */
#include "ipport.h"
#include "libport.h"
#include "osport.h"
#include "tcpport.h"
#include "net.h"

/* Video Display/Graphics. */
#include "alt_video_display/alt_video_display.h"
#include "graphics_lib/simple_graphics.h"
#include "fonts/fonts.h"

/* SD Card FAT */
#include "elca_fat/elca_fat.h"

#ifndef ALT_INICHE
  #error This Web Server requires the Interniche IP Stack Software Component.
#endif

#ifndef __ucosii__
  #error This Web Server requires the UCOS II IP Software Component.
#endif

extern int current_flash_block;

char shorty[13];

extern int FATLongNameMap( char shortname[], char longname[] );
extern void ls();

extern void WSTask();

/* NicheStack network structure. */
extern struct net netstatic[STATIC_NETS];


/* Declarations for creating a task with TK_NEWTASK.  
 * All tasks which use NicheStack (those that use sockets) must be created this way.
 * TK_OBJECT macro creates the static task object used by NicheStack during operation.
 * TK_ENTRY macro corresponds to the entry point, or defined function name, of the task.
 * inet_taskinfo is the structure used by TK_NEWTASK to create the task.
 */

TK_OBJECT(to_wstask);
TK_ENTRY(WSTask);

struct inet_taskinfo wstask = {
      &to_wstask,
      "web server",
      WSTask,
      HTTP_PRIO,
      APP_STACK_SIZE,
};

/* Function which displays the obtained (or assigned) IP
 * Address on the LCD Display.
 */

void lcd_ip_addr()
{
  /* Declare local network variables. */
  ip_addr* ipaddr;
  ip_addr* netmsk;
  ip_addr* gw;

  /* Video Display. */
  alt_video_display* display;
  char welcome_txt[80];
  char msg_txt[500];

  /* Assign ipaddr to the network interface's IP Address.
   * NOTE:  This code assumes that only a single network
   * interface exists
   */
  ipaddr = &nets[0]->n_ipaddr;
  netmsk = &nets[0]->snmask;
  gw = &nets[0]->n_defgw;

  /* Initialize the video display. */
  display = alt_video_display_init( ALT_VIDEO_DISPLAY_SGDMA_NAME,         // char* sgdma_name
                                    ALT_VIDEO_DISPLAY_COLS,               // int width
                                    ALT_VIDEO_DISPLAY_ROWS,               // int height
                                    ALT_VIDEO_DISPLAY_COLOR_DEPTH,        // int color_depth
                                    ALT_VIDEO_DISPLAY_USE_HEAP,           // int buffer_location
                                    ALT_VIDEO_DISPLAY_USE_HEAP,           // int descriptor_location
                                    2 );                                  // int num_buffers

  /* Prepare Text to go on the screen. */
  sprintf( welcome_txt, "Welcome to the Web Server Application");
  sprintf( msg_txt, "The Nios II Processor system will now serve content from the SD Card.\n\t1) Connect an Ethernet cable from your Kit to a network.\n\t2) On your host system, open a web browser \n\t\t  and type in the IP Address below.\n\n\t\tIP Address:\t%d.%d.%d.%d\n\t\tNetmask:     %d.%d.%d.%d\n\t\tGateway:     %d.%d.%d.%d\n\nClick on the instructions link in the lefthand column of the web page.\nFollow the instructions to remotely configure your kit.\n\nFor more information, please refer to the User's Guide.",
          ip4_addr1(*ipaddr),
          ip4_addr2(*ipaddr),
          ip4_addr3(*ipaddr),
          ip4_addr4(*ipaddr),
          ip4_addr1(*netmsk),
          ip4_addr2(*netmsk),
          ip4_addr3(*netmsk),
          ip4_addr4(*netmsk),
          ip4_addr1(*gw),
          ip4_addr2(*gw),
          ip4_addr3(*gw),
          ip4_addr4(*gw)); 
  /* Print to screen. */
  vid_print_string_alpha( 0,
                          0,
                          FG_COLOR,
                          BG_COLOR,
                          WELCOME_FONT,
                          display,
                          welcome_txt);
  vid_print_string_alpha( 0,
                          80,
                          FG_COLOR,
                          BG_COLOR,
                          MSG_FONT,
                          display,
                          msg_txt);

  alt_video_display_register_written_buffer( display );

}


/* Function which resets the system.  Initiated through the Reset System form. 
 */
void reconfig_fpga()
{
  volatile int hw_offset = RECONFIG_ADDRESS;
  volatile int remote_update_base = REMOTE_UPDATE_BASE;  
  
  volatile int read_offset;

  // First disable the watchdog timer
  IOWR( remote_update_base, 0x3, 0  );

  usleep(1000);

  // Next write the offset of the hardware image in flash
  IOWR( remote_update_base, 0x4, hw_offset >> 3  );

  read_offset = (IORD( remote_update_base, 0x4 )<<4);

  usleep(1000);

  // Make sure the flash is in read mode
  IOWR_16DIRECT( EXT_FLASH_BASE, 0, 0xFFFF );
  IOWR_8DIRECT( EXT_FLASH_BASE, 0, 0xFF );

  printf("Reconfiguring to offset 0x%x.\n", hw_offset );

  usleep(10000);

  // Reconfigure
  IOWR( remote_update_base, 0x20, 0x1 );

  while( 1 );

  return;
}

/* WSInitialTask will initialize the NichStack TCP/IP stack and then initialize
 * the rest of the web server example tasks.
 */

void WSInitialTask(void* pdata)
{
  INT8U error_code = OS_NO_ERR;
  char longname[64];
  char shortname[13];

  /*
  * Initialize Altera NicheStack TCP/IP Stack - Nios II Edition specific code.
  * NicheStack is initialized from a task, so that RTOS will have started, and 
  * I/O drivers are available.  Two tasks are created:
  *    "Inet main"  task with priority 2
  *    "clock tick" task with priority 3
  */   
  alt_iniche_init();
  /* Start the Iniche-specific network tasks and initialize the network
   * devices.
   */
  netmain(); 
  /* Wait for the network stack to be ready before proceeding. */
  while (!iniche_net_ready)
    TK_SLEEP(1);

  /* Create the main network task.  In this case, a web server. */
  TK_NEWTASK(&wstask);

  /* Application specific code starts here... */

  /* Mount the El Camino FAT filesystem on the SD Card. */

  printf("INFO:  Initializing El Camino SD/SPI controller & FAT file system...\n");

  if( elca_fat_mount( EL_CAMINO_SD_CARD_CONTROLLER_NAME) < 0 )
  {
    printf("ERROR: Failed to mount %s\n", EL_CAMINO_SD_CARD_CONTROLLER_NAME );
    printf("ERROR: Web Content access will fail!\n" );
  }
  printf("INFO:  Success!\n");

  /* Find the DOS "shortname" representation of the "longname". */

  strcpy( longname, HTTP_DEFAULT_DIR );

  if( (FATLongNameMap( shortname, longname )) < 0 )
  {
    printf( "Cannot find %s directory.  Does it exist on your SD Card?", longname );
  }

  printf( "Short filename = %s.\n", shortname );
  
  if( elca_chdir( shortname ) != ELCA_F_OK )
  {
    printf("ERROR:  Failed to change directory to %s!\n", HTTP_DEFAULT_DIR );
    printf("ERROR:  Web Content access will fail!\n" );
  } 

  ls();

  /*Create Tasks*/
  printf("\nWeb Server starting up\n");
  /* Application specific code ends here. */

  lcd_ip_addr();

  /*This task deletes itself, since there's no reason to keep it around, once
   *it's complete.
   */
  error_code = OSTaskDel(OS_PRIO_SELF);
  alt_uCOSIIErrorHandler(error_code, 0);

  while(1); /*Correct Program Flow should not reach here.*/
}

/* Definition of Task Stacks for tasks not using networking.*/


OS_STK    WSInitialTaskStk[2*TASK_STACKSIZE];

int main (int argc, char* argv[], char* envp[])
{
  /* Initialize the current flash block, for flash programming. */
  
  current_flash_block = -1;
  
  INT8U error_code;

  /* Clear the RTOS timer */
  OSTimeSet(0);
  
  /* WSInitialTask will initialize the NicheStack TCP/IP Stack and then 
   * initialize the rest of the web server's tasks.
   */ 

  error_code = OSTaskCreateExt(WSInitialTask,
                             NULL,
                             (void *)&WSInitialTaskStk[TASK_STACKSIZE],
                             WS_INITIAL_TASK_PRIO,
                             WS_INITIAL_TASK_PRIO,
                             WSInitialTaskStk,
                             TASK_STACKSIZE,
                             NULL,
                             0);
  alt_uCOSIIErrorHandler(error_code, 0);


  /*
   * As with all MicroC/OS-II designs, once the initial thread(s) and 
   * associated RTOS resources are declared, we start the RTOS. That's it!
   */
  OSStart();
  
  while(1); /* Correct Program Flow never gets here. */

  return -1;
}

/******************************************************************************
*                                                                             *
* License Agreement                                                           *
*                                                                             *
* Copyright (c) 2006 Altera Corporation, San Jose, California, USA.           *
* All rights reserved.                                                        *
*                                                                             *
* Permission is hereby granted, free of charge, to any person obtaining a     *
* copy of this software and associated documentation files (the "Software"),  *
* to deal in the Software without restriction, including without limitation   *
* the rights to use, copy, modify, merge, publish, distribute, sublicense,    *
* and/or sell copies of the Software, and to permit persons to whom the       *
* Software is furnished to do so, subject to the following conditions:        *
*                                                                             *
* The above copyright notice and this permission notice shall be included in  *
* all copies or substantial portions of the Software.                         *
*                                                                             *
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR  *
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,    *
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE *
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER      *
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING     *
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER         *
* DEALINGS IN THE SOFTWARE.                                                   *
*                                                                             *
* This agreement shall be governed in all respects by the laws of the State   *
* of California and by the laws of the United States of America.              *
* Altera does not recommend, suggest or require that this reference design    *
* file be used in conjunction or combination with any other product.          *
******************************************************************************/
