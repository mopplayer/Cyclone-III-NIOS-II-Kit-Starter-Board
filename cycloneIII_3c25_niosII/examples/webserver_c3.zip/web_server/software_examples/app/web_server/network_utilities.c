/******************************************************************************
* Copyright (c) 2006 Altera Corporation, San Jose, California, USA.           *
* All rights reserved. All use of this software and documentation is          *
* subject to the License Agreement located at the end of this file below.     *
*******************************************************************************
*                                                                             *
* Modified to work with Interniche (Week of 9/22/06) - BjR                    *
*                                                                             *
* File: network_utilities.c                                                   *
*                                                                             *
* This file contains network utilities that work in conjunction with the      *
* NicheStack to bring up a design's IP address (using DHCP if available) and  *
* MAC address.                                                                *
*                                                                             *
* Please refer to file ReadMe.txt for notes on this software example.         *
******************************************************************************/
#include <stdio.h> 
#include <ctype.h>
#include <string.h>
#include <errno.h>

/* Iniche Specific includes. */

#include <alt_iniche_dev.h>
#include "ipport.h"
#include "tcpport.h"

#include "alt_eeprom/alt_2_wire.h"
#include "alt_eeprom/alt_eeprom.h"

#include "alt_types.h"
#include "sys/alt_flash.h"
#include "includes.h"
#include "io.h"
#include "web_server.h"

#define IP4_ADDR(ipaddr, a,b,c,d) ipaddr = \
    htonl(((alt_u32)(a & 0xff) << 24) | ((alt_u32)(b & 0xff) << 16) | \
          ((alt_u32)(c & 0xff) << 8) | (alt_u32)(d & 0xff))

struct device devices[] = {
    { 0,    0x10,   0xA0,   0xA1    },
    { 8,    0x400,  0xA0,   0xA1    },
    { 16,   0x800,  0xA0,   0xA1    },
};

struct device *device = &(devices[0]);

/*
 * MicroC/OS-II semaphores are used to signal when an IP address has been
 * aquired (declared in web_serer.c), and when the LCD may be opened for
 * write.
 */
extern OS_EVENT *attained_ip_address_sem;
#ifdef LCD_DISPLAY_NAME  
OS_EVENT *lcd_sem;

/* File handle for writing to LCD display. Defined in web_server.c */
extern FILE* lcdDevice;
#endif /* LCD_DISPLAY_NAME */

/*
 * die_with_error()
 * 
 * This routine is just called when a blocking error occurs with the example
 * design. It deletes the current task.
 */
void die_with_error(char err_msg[DIE_WITH_ERROR_BUFFER])
{
  printf("\n%s\n", err_msg);
  OSTaskDel(OS_PRIO_SELF);
  
  while(1);
}

error_t get_board_mac_addr(unsigned char mac_addr[6],struct device *device)
{
  error_t error = 0;

  alt_u32 signature = 0;

  alt_two_wire s_eeprom;
  alt_two_wire* eeprom = &s_eeprom;

/* Initialize the EEPROM. */
  
  eeprom->scl_pio = PIO_ID_EEPROM_SCL_BASE;
  eeprom->sda_pio = PIO_ID_EEPROM_DAT_BASE;

  alt_2_wireInit(eeprom);
  alt_2_wireSetDelay(10);

  printf("EEPROM device 24LC%d size is %x\n", device->id, device->size);

  char *buf = malloc(10);

  if (!error)
  {
    if(!readRandom(device, 0, buf, 10)) {
      printf( "Successfully read 16 bytes from EEPROM.\n");
      signature = (buf[2]*0x10000 & 0xff0000) + (buf[3]*0x100 & 0xff00) + (buf[4] & 0xff);
    }
    printf( "Signature = 0x%x.\n", (unsigned int) signature);
    if (signature != 0x0007ed)
    {
      printf( "Your EEK LCD daughtercard is not programmed with a correct MAC Address!\n");
      printf( "Please contact Altera support for instructions on how to correct this problem!\n");
    }
  }
  
  if (!error)
  {
    mac_addr[0] = buf[2] & 0xFF;
    mac_addr[1] = buf[3] & 0xFF;
    mac_addr[2] = buf[4] & 0xFF;
    mac_addr[3] = buf[5] & 0xFF;
    mac_addr[4] = buf[6] & 0xFF;
    mac_addr[5] = buf[7] & 0xFF;
    
    printf("Your Ethernet MAC address is %02x:%02x:%02x:%02x:%02x:%02x\n", 
            mac_addr[0],
            mac_addr[1],
            mac_addr[2],
            mac_addr[3],
            mac_addr[4],
            mac_addr[5]);

  }
  free(buf);
  
  return error;
}


/*
* get_mac_addr
*
* Read the MAC address in a board specific way
*
*/
int get_mac_addr(NET net, unsigned char mac_addr[6])
{
    return (get_board_mac_addr(mac_addr, device));
}

/*
 * get_ip_addr()
 * 
 * This routine is called by InterNiche to obtain an IP address for the
 * specified network adapter. Like the MAC address, obtaining an IP address is
 * very system-dependant and therefore this function is exported for the
 * developer to control.
 * 
 * In our system, we are either attempting DHCP auto-negotiation of IP address,
 * or we are setting our own static IP, Gateway, and Subnet Mask addresses our
 * self. This routine is where that happens.
 *zzz add LCD display
 */
int get_ip_addr(alt_iniche_dev *p_dev,
                ip_addr* ipaddr, 
                ip_addr* netmask,
                ip_addr* gw,
                int* use_dhcp)
{
    int got_ip_addr = 0;

    if (strcmp(p_dev->name, "/dev/" INICHE_DEFAULT_IF))
        return (got_ip_addr);

#ifdef DHCP_CLIENT

    IP4_ADDR(*ipaddr, IPADDR0, IPADDR1, IPADDR2, IPADDR3);
    IP4_ADDR(*gw, GWADDR0, GWADDR1, GWADDR2, GWADDR3);
    IP4_ADDR(*netmask, MSKADDR0, MSKADDR1, MSKADDR2, MSKADDR3);
    *use_dhcp = 1;

#else /* not DHCP_CLIENT */

    IP4_ADDR(*ipaddr, IPADDR0, IPADDR1, IPADDR2, IPADDR3);
    IP4_ADDR(*gw, GWADDR0, GWADDR1, GWADDR2, GWADDR3);
    IP4_ADDR(*netmask, MSKADDR0, MSKADDR1, MSKADDR2, MSKADDR3);
    *use_dhcp = 0;

    printf("Static IP Address is %d.%d.%d.%d\n", 
        ip4_addr1(*ipaddr),
        ip4_addr2(*ipaddr),
        ip4_addr3(*ipaddr),
        ip4_addr4(*ipaddr));

#endif /* not DHCP_CLIENT */

    got_ip_addr = 1;

    return (got_ip_addr);
}
/******************************************************************************
*                                                                             *
* License Agreement                                                           *
*                                                                             *
* Copyright (c) 2006 Altera Corporation, San Jose, California, USA.           *
* All rights reserved.                                                        *
*                                                                             *
* Permission is hereby granted, free of charge, to any person obtaining a     *
* copy of this software and associated documentation files (the "Software"),  *
* to deal in the Software without restriction, including without limitation   *
* the rights to use, copy, modify, merge, publish, distribute, sublicense,    *
* and/or sell copies of the Software, and to permit persons to whom the       *
* Software is furnished to do so, subject to the following conditions:        *
*                                                                             *
* The above copyright notice and this permission notice shall be included in  *
* all copies or substantial portions of the Software.                         *
*                                                                             *
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR  *
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,    *
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE *
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER      *
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING     *
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER         *
* DEALINGS IN THE SOFTWARE.                                                   *
*                                                                             *
* This agreement shall be governed in all respects by the laws of the State   *
* of California and by the laws of the United States of America.              *
* Altera does not recommend, suggest or require that this reference design    *
* file be used in conjunction or combination with any other product.          *
******************************************************************************/
