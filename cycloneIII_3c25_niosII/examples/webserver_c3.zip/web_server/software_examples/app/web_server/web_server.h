#ifndef __WEB_SERVER_H__
#define __WEB_SERVER_H__
/******************************************************************************
* Copyright (c) 2006 Altera Corporation, San Jose, California, USA.           *
* All rights reserved. All use of this software and documentation is          *
* subject to the License Agreement located at the end of this file below.     *
*******************************************************************************
*                                                                             *
* File: user.h                                                                *
*                                                                             *
* Headers for our application. HTTP server-specific headers can be found in   *
* file http.c.                                                                *
*                                                                             *
* Please refer to file ReadMe.txt for notes on this software example.         *
******************************************************************************/

#include "alt_types.h"
#include "includes.h"
/*
 * Prototypes:
 *    die_with_error() - Kills current task and delivers error message to 
 *                       STDERR.
 * 
 * dhcp_timeout_task() - Keeps track of whether an IP address has been 
 *                       aquired from a DHCP server, or times out and resorts
 *                       to a static IP address.
 * 
 *         http_task() - Manages HTTP connections and calls relevant 
 *                       subroutines to service HTTP requests.
 */
void die_with_error(char err_msg[]);

struct http_form_data
{
  alt_u8 LED_ON;
  alt_u8 SSD_ON;
  alt_u8 LCD_TEXT[20];
  alt_u8 File_Upload[20];
};

extern FILE* lcdDevice;

struct   tcpstat
{
   u_long   tcps_connattempt;    /* connections initiated */
   u_long   tcps_accepts;        /* connections accepted */
   u_long   tcps_connects;       /* connections established */
   u_long   tcps_drops;          /* connections dropped */
   u_long   tcps_conndrops;      /* embryonic connections dropped */
   u_long   tcps_closed;         /* conn. closed (includes drops) */
   u_long   tcps_segstimed;      /* segs where we tried to get rtt */
   u_long   tcps_rttupdated;     /* times we succeeded */
   u_long   tcps_delack;         /* delayed acks sent */
   u_long   tcps_timeoutdrop;    /* conn. dropped in rxmt timeout */
   u_long   tcps_rexmttimeo;     /* retransmit timeouts */
   u_long   tcps_persisttimeo;   /* persist timeouts */
   u_long   tcps_keeptimeo;      /* keepalive timeouts */
   u_long   tcps_keepprobe;      /* keepalive probes sent */
   u_long   tcps_keepdrops;      /* connections dropped in keepalive */

   u_long   tcps_sndtotal;       /* total packets sent */
   u_long   tcps_sndpack;        /* data packets sent */
   u_long   tcps_sndbyte;        /* data bytes sent */
   u_long   tcps_sndrexmitpack;  /* data packets retransmitted */
   u_long   tcps_sndrexmitbyte;  /* data bytes retransmitted */
   u_long   tcps_sndacks;        /* ack-only packets sent */
   u_long   tcps_sndprobe;       /* window probes sent */
   u_long   tcps_sndurg;         /* packets sent with URG only */
   u_long   tcps_sndwinup;       /* window update-only packets sent */
   u_long   tcps_sndctrl;        /* control (SYN|FIN|RST) packets sent */

   u_long   tcps_rcvtotal;       /* total packets received */
   u_long   tcps_rcvpack;        /* packets received in sequence */
   u_long   tcps_rcvbyte;        /* bytes received in sequence */
   u_long   tcps_rcvbadsum;      /* packets received with ccksum errs */
   u_long   tcps_rcvbadoff;      /* packets received with bad offset */
   u_long   tcps_rcvshort;       /* packets received too short */
   u_long   tcps_rcvduppack;     /* duplicate-only packets received */
   u_long   tcps_rcvdupbyte;     /* duplicate-only bytes received */
   u_long   tcps_rcvpartduppack; /* packets with some duplicate data */
   u_long   tcps_rcvpartdupbyte; /* dup. bytes in part-dup. packets */
   u_long   tcps_rcvoopack;      /* out-of-order packets received */
   u_long   tcps_rcvoobyte;      /* out-of-order bytes received */
   u_long   tcps_rcvpackafterwin;   /* packets with data after window */
   u_long   tcps_rcvbyteafterwin;   /* bytes rcvd after window */
   u_long   tcps_rcvafterclose;  /* packets rcvd after "close" */
   u_long   tcps_rcvwinprobe;    /* rcvd window probe packets */
   u_long   tcps_rcvdupack;      /* rcvd duplicate acks */
   u_long   tcps_rcvacktoomuch;  /* rcvd acks for unsent data */
   u_long   tcps_rcvackpack;     /* rcvd ack packets */
   u_long   tcps_rcvackbyte;     /* bytes acked by rcvd acks */
   u_long   tcps_rcvwinupd;      /* rcvd window update packets */

   u_long   tcps_mcopies;        /* m_copy() actual copies */
   u_long   tcps_mclones;        /* m_copy() clones */
   u_long   tcps_mcopiedbytes;   /* m_copy() # bytes copied */
   u_long   tcps_mclonedbytes;   /* m_copy() # bytes cloned */

   u_long   tcps_oprepends;      /* ip_output() prepends of header to data */
   u_long   tcps_oappends;       /* ip_output() appends of data to header */
   u_long   tcps_ocopies;        /* ip_output() copies */
   u_long   tcps_predack;        /* VJ predicted-header acks */
   u_long   tcps_preddat;        /* VJ predicted-header data packets */
   u_long   tcps_zioacks;        /* acks recvd during zio sends */
#ifdef TCP_SACK
   u_long   tcps_sackconn;       /* connections which negotiated SACK */
   u_long   tcps_sacksent;       /* SACK option headers sent */
   u_long   tcps_sackresend;     /* segs resent because of recv SACKs */
   u_long   tcps_sackrcvd;       /* SACK option headers received */
   u_long   tcps_sackmaxblk;     /* most SACK blocks in a received option field */
#endif /* TCP_SACK */
};

extern struct tcpstat tcpstat;
/* 
 * The IP, gateway, and subnet mask address below are used as a last resort if 
 * if no network settings can be found, and DHCP (if enabled) fails. You can
 * edit these as a quick-and-dirty way of changing network settings if desired.
 * 
 * Default fall-back address:
 *           IP: 192.168.1.234
 *      Gateway: 192.168.1.1
 *  Subnet Mask: 255.255.255.0
 */
#define IPADDR0   0 
#define IPADDR1   0 
#define IPADDR2   0 
#define IPADDR3   0

#define GWADDR0   0 
#define GWADDR1   0 
#define GWADDR2   0 
#define GWADDR3   0

#define MSKADDR0  0
#define MSKADDR1  0
#define MSKADDR2  0
#define MSKADDR3  0

/*
 * Task priorities
 *
 * MicroC/OS-II only allows one task (thread) per priority number. Our web
 * SERVER task is given a high priority (lower only than timers which must run 
 * when they need to) so that we can focus on pushing data *out* of the system.
 * An ethernet CLIENT application would have lower prioritization than the 
 * stack & ethernet tasks.
 */
#define HTTP_PRIO     4
#define LED_PRIO      6
#define SSD_PRIO      7
#define BOARD_PRIO    8
#define WS_INITIAL_TASK_PRIO 1
/* 
 * Buffer size for a routine to call if things fail
 */
 
/* Definition of Task Stacks for tasks not using networking. */
#define   TASK_STACKSIZE       2048
#define   APP_STACKSIZE        4096


extern OS_STK    WSInitialTaskStk[2*TASK_STACKSIZE];
extern OS_STK    BCTaskStk[TASK_STACKSIZE];
extern OS_STK    LEDTaskStk[TASK_STACKSIZE];
extern OS_STK    SSDTaskStk[TASK_STACKSIZE];

#define DIE_WITH_ERROR_BUFFER 256

/* Default reconfiguration address for CIII NEEK board.
 *   - Assume "user" application.
 *     NOTE:  This maps to the "UNUSED" section of flash
 *            as defined by the NEEK application selector.
 */

#define RECONFIG_ADDRESS 0xe00000
#define FLASH_DEVICE "ext_flash"

/* LCD Display constants. */

#define ALT_VIDEO_DISPLAY_COLS 800
#define ALT_VIDEO_DISPLAY_ROWS 480
#define ALT_VIDEO_DISPLAY_COLOR_DEPTH 32
#define ALT_VIDEO_DISPLAY_SGDMA_NAME LCD_SGDMA_NAME

#define FG_COLOR 0x00FFFFFF
#define BG_COLOR 0x00000000
#define WELCOME_FONT tahomabold_32
#define MSG_FONT tahomabold_20


#endif /* __WEB_SERVER_H__ */

/******************************************************************************
*                                                                             *
* License Agreement                                                           *
*                                                                             *
* Copyright (c) 2006 Altera Corporation, San Jose, California, USA.           *
* All rights reserved.                                                        *
*                                                                             *
* Permission is hereby granted, free of charge, to any person obtaining a     *
* copy of this software and associated documentation files (the "Software"),  *
* to deal in the Software without restriction, including without limitation   *
* the rights to use, copy, modify, merge, publish, distribute, sublicense,    *
* and/or sell copies of the Software, and to permit persons to whom the       *
* Software is furnished to do so, subject to the following conditions:        *
*                                                                             *
* The above copyright notice and this permission notice shall be included in  *
* all copies or substantial portions of the Software.                         *
*                                                                             *
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR  *
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,    *
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE *
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER      *
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING     *
* FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER         *
* DEALINGS IN THE SOFTWARE.                                                   *
*                                                                             *
* This agreement shall be governed in all respects by the laws of the State   *
* of California and by the laws of the United States of America.              *
* Altera does not recommend, suggest or require that this reference design    *
* file be used in conjunction or combination with any other product.          *
******************************************************************************/
