/* This file contains various utilities, in addition to the routines provided
   by elca_fat.
*/

#include "elca_fat/elca_fat.h"
#include <string.h>
#include <stdio.h>

extern char shorty[13];


/* Simple ls function for viewing the contents of a FAT directory. */

void ls(void)
{
  if(elca_findfirst()!=0) 
  { 
    do 
    {
      printf("    %s   ",ffblk.ff_name); //8.3 DOS Name
      if(ffblk.ff_attr==ATTR_FILE) 
      {
        printf("%9ld",ffblk.ff_fsize);
        printf("    %s\n",ffblk.ff_longname);//"long" filename
      }
      if(ffblk.ff_attr==ATTR_DIRECTORY) 
      {
        printf("    <DIR>\n");
      }
    } while(elca_findnext()!=0); //Find next file or directory
  } 
  else 
  {
    printf("    No files/directories found!\n");
  }
}


/* The following function maps the longname to the DOS "short naming" style
   using the elca_findfirst() function provided by El Camino.
*/

int FATLongNameMap( char shortname[], char longname[] )
{
  int found_name = 0;
  int ret_code = 0;

  strcpy( shorty, "NOT_FOUND" );
  

  // Clear the shortname and longname since the elca_findx functions dont do it for us.
  //memset( ffblk.ff_longname, 0x0, _MAX_NAME );
  //memset( ffblk.ff_name, 0x0, 12 );

  // Look for any directories who's long or short names match ours
  if( elca_findfirst() != 0 ) //Find first file
  {
    do
    {
      if ( ffblk.ff_name[0] != '.' )
      {
        if(( !strcmp( ffblk.ff_name, longname )) ||
           ( !strcmp( ffblk.ff_longname, longname )))
        {
          found_name = 1;
          break;
        }
      }
      //memset( ffblk.ff_longname, 0x0, _MAX_NAME );
      //memset( ffblk.ff_name, 0x0, 12 );
    } while( elca_findnext() != 0 ); //Find next file or directory
  }

  if( found_name )
  {
    strcpy( shortname, ffblk.ff_name );
  }
  else
  {
    ret_code = -1;
  }
  return( ret_code );
}

