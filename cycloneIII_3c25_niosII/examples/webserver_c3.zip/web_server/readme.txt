Overview:

- This design is based on the Nios II/f core and provides a typical mix of 
  peripherals and memories as well as a video pipeline. The SOPC Builder system
  provides an interface to each hardware component on the embedded evaluation 
  kit board, such as DDR SDRAM, LEDs, RS-232 connector, and the Ethernet 
  MAC/10/100 PHY as well as the 800 x 240 pixel RGB LCD. There is also a video 
  pipeline which provides high bandwidth memory access that allows for flicker 
  free display on the color LCD.

- This is a list of the components available in the system along with a brief 
  description:
  cpu Nios2/f
  flash_ssram_pipeline_bridge
  pipeline_bridge_before_tristate_bridge
  flash_ssram_tristate_bridge
  ssram 1 MByte synchronous SRAM
  ext_flash 16MByte parallel flash
  ddr_sdram 1 Mbyte DDR SDRAM
  cpu_ddr_clock_bridge

Components on the slow peripheral bridge
=========================================
- Components listed here are partitioned off by the use of the 
  slow_peripheral_bridge. This allows non-fmax critical components to be 
  clocked at a slower clock rate to give better fitting for components that 
  are fmax-critical.

  - The Bridge
    * slow_peripheral_bridge

  - The triple speed Ethernet components:
    * tse_mac
    * sgdma_tx
    * sgdma_rx
    * descriptor_memory

- These bridges are here for two reasons:
  1) Clock cross between two components that are clocked at a different 
     frequency.
     * tse_ddr_clock_bridge
     * tse_ssram_clock_bridge

  2) To offset addresses so that the entire memory model is flat. 
     (Every master sees every slave at the same address). 
     * descriptor_offset_bridge


  - The rest of the components on the slow_peripheral_bridge
    * sys_clk_timer 
    * performance_counter
    * jtag_uart
    * sysid
    * pll
    * button_pio
    * led_pio
    * pio_id_eeprom_dat 
    * pio_id_eeprom_scl used to access EEProm
    * remote_update

  - The following components are used to communicate with the touch panel 
    * touch_panel_spi
    * touch_panel_pen_irq_n

  - The sd card solution is provided under license agreement with El Camino 
    (http://www.elcamino.de)
    * el_camino_sd_card_controller

The video pipeline:
===================
- The following i2c pins are used to configure the lcd panel for brightness and
  gamma curves
  * lcd_i2c_scl
  * lcd_i2c_en
  * lcd_i2c_sdat

- The rest of the components that make up the video pipeline:
  * lcd_sgdma
  * lcd_ta_sgdma_to_fifo
  * lcd_pixel_fifo
  * lcd_ta_fifo_to_dfa
  * lcd_64_to_32_bits_dfa
  * lcd_pixel_converter
  * lcd_32_to_8_bits_dfa
  * lcd_sync_generator

Further Notes:
==============
- This design contains a PLL that produces a phase-shifted clock to feed the 
  SSRAM. The phase shift is board-dependent, and may be different if this 
  design is retargeted to a different board.

- This Quartus II project contains assignments that match the port names 
  produced by SOPC Builder. If you add or modify SOPC Builder components, the 
  pin assignments may no longer be valid.  To view the Assignment Editor in the
  Quartus II software, in the Assignments menu, click "Assignment Editor".

- Hardcoded library paths will be inserted into the Quartus settings for this 
  project during system generation due to the presence of the DDR and TSE 
  components.  If you intend to modify the hardware and regenerate a system 
  with these components, please remove any old paths from within the project
  settings file (qsf) IF the project directory has been changed.

  An example of the absolute paths are shown below:
     set_global_assignment -name USER_LIBRARIES "C:/niosII_cycloneII_2c35/full_featured;"
     set_global_assignment -name VHDL_FILE "C:/MegaCore/ddr_ddr2_sdram-v3.2.0/lib/auk_ddr_tb_functions.vhd"
     set_global_assignment -name VHDL_FILE "C:/MegaCore/ddr_ddr2_sdram-v3.2.0/lib/auk_ddr_functions.vhd"
     set_global_assignment -name VHDL_FILE "C:/MegaCore/ddr_ddr2_sdram-v3.2.0/lib/auk_ddr_input_buf.vhd"
     set_global_assignment -name VHDL_FILE "C:/MegaCore/ddr_ddr2_sdram-v3.2.0/lib/auk_ddr_timers.vhd"
     set_global_assignment -name VHDL_FILE "C:/MegaCore/ddr_ddr2_sdram-v3.2.0/lib/auk_ddr_avalon_if.vhd"
     set_global_assignment -name VHDL_FILE "C:/MegaCore/ddr_ddr2_sdram-v3.2.0/lib/auk_ddr_bank_details.vhd"
     set_global_assignment -name VHDL_FILE "C:/MegaCore/ddr_ddr2_sdram-v3.2.0/lib/auk_ddr_controller.vhd"
     set_global_assignment -name VHDL_FILE "C:/MegaCore/ddr_ddr2_sdram-v3.2.0/lib/auk_ddr_init.vhd"
     set_global_assignment -name VERILOG_FILE "C:/niosII_cycloneII_2c35/full_featured/ddr_sdram_auk_ddr_dqs_group.v"
     set_global_assignment -name VERILOG_FILE "C:/niosII_cycloneII_2c35/full_featured/ddr_sdram_auk_ddr_clk_gen.v"
     set_global_assignment -name VERILOG_FILE "C:/niosII_cycloneII_2c35/full_featured/ddr_sdram_auk_ddr_datapath.v"
     set_global_assignment -name VERILOG_FILE "C:/niosII_cycloneII_2c35/full_featured/ddr_sdram_auk_ddr_sdram.v"
     set_global_assignment -name VERILOG_FILE "C:/niosII_cycloneII_2c35/full_featured/ddr_sdram.v"

     * These paths have been pre-removed in the qsf of the designs shipped in 
       the installation.

- DDR memory is the main memory of the system, however SSRAM has a faster 
  access speed (when using the same clock frequencies).  

- The current version of the Nios II EDS hardware design example uses an HDL 
  file as the top level of the design hierarchy.  If you would like to use a 
  schematic-based top level instead (BDF), follow the steps listed below.  
    1) In the Quartus II software, open the top-level HDL file (.v or .vhd) for
       the design.
    2) Create a symbol for the HDL file by clicking 
       File -> Create/Update -> Create Symbol Files for Current File
    3) Create a new BDF file by clicking 
       File -> New -> Block Diagram/Schematic File.
    4) Instantiate the symbol in the BDF by double-clicking in the empty space
       of the BDF file and selecting "Project -> <symbol filename>"
    5) Instantiate pins in the BDF by double-clicking empty space, then 
       typing "input", "output", or "bidir".
    6) Rename the pins and connect them to the appropriate ports on the symbol.
    7) Save the BDF as a unique filename.
    8) Set the BDF as your top level entity by clicking:
       Project -> Set as Top-Level Entity
    9) Recompile the Quartus II project.

  For more information and details, refer to the Nios II Embedded Design Suite 
  Release Note.
