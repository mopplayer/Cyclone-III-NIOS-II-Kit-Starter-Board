To prepare your own jpeg_images.zip file, be sure to rename the JPEG files sequentially eg. 1.jpg, 2.jpg, 3.jpg and so on
Make sure to zip the files in the uncompressed format , and in the correct directory hierarchy .
