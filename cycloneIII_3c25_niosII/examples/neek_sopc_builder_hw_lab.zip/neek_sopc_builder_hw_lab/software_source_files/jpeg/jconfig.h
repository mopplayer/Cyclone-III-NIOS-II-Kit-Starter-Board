//#include "jpeglib.h"
#define HAVE_PROTOTYPES
#define HAVE_UNSIGNED_CHAR
#define HAVE_UNSIGNED_SHORT
#define HAVE_STDDEF_H
#define HAVE_STDLIB_H

//#define JDCT_DEFAULT JDCT_FLOAT
